#!/system/bin/sh

mount -t ext2 /dev/block/sda3 /mnt/shared

cd /data/local/tmp
rm -rf ramdisk_patch
mkdir ramdisk_patch
cd ramdisk_patch
gunzip -c /mnt/shared/ramdisk | cpio -i

cp /system/boot_default_prop.patch p.prop
cat default.prop >> p.prop
mv p.prop default.prop
chmod 644 default.prop

find . | cpio -o -H newc | gzip > ../ramdisk

cat /data/local/tmp/ramdisk > /mnt/shared/ramdisk

umount /mnt/shared
